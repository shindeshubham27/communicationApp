<?php
require("fns_output.php");
require("db.php");
require("db_fns.php");
include("Header.php");

// Function to sanitize user input

session_start();
$email =  $_SESSION["email"];

function sanitize($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Function to get chats from the database
function getChats($db) {
    $query = "SELECT * FROM chat ORDER BY chattime";
    $result =  mysqli_query($db, $query);
    return $result;
}

// Function to insert chat into the database
function insertChat($db, $email, $chat) {
    $time = date('Y-m-d H:i:s');
    $query = "INSERT INTO chat (email, chat, chattime) VALUES ('$email', '$chat', '$time')";
    mysqli_query($db, $query);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $chat = sanitize($_POST['chat']);
    if (!empty($chat)) {
        insertChat($db, $email, $chat);
        // Redirect to clear the form after submission
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Group Chat</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
            text-align: left;
        }
        input[type="text"] {
            width: 80%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .refresh-button {
            background-color: #f44336;
        }
        .refresh-button:hover {
            background-color: #d32f2f;
        }
    </style>
</head>
<body>
    <h2>Group Chat</h2>
    <table>
        <tr>
            <th>Time</th>
            <th>Username</th>
            <th>Chat</th>
        </tr>
        <?php
        $chatResult = getChats($db);
        while ($row = mysqli_fetch_assoc($chatResult)) {
            echo "<tr>";
            echo "<td>{$row['chattime']}</td>";
            echo "<td>{$row['email']}</td>";
            echo "<td>{$row['chat']}</td>";
            echo "</tr>";
        }
        ?>
    </table>
    <form method="post">
        <input type="text" name="chat" placeholder="Type your message..." required>
        <input type="submit" name="submit" value="Send">
        <button class="refresh-button" type="button" onclick="document.querySelector('input[name=\'chat\']').value = '';">Clear</button>
    </form>
</body>
</html>
