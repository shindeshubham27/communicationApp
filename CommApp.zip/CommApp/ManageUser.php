<?php
// Include your database connection file
require("fns_output.php");
require("db.php");
require("db_fns.php");
include("Header.php");

// Function to sanitize user input
function sanitize($data)
{
    return htmlspecialchars(stripslashes(trim($data)));
}

// Query to fetch users from the database
$query = "SELECT * FROM user";
$result = mysqli_query($db, $query);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
        }

        .edit-button,
        .delete-button {
            padding: 6px 12px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <h2>Manage Users</h2>
    <table>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Actions</th>
        </tr>
        <?php
        // Display users from database
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>{$row['fullname']}</td>";
            echo "<td>{$row['email']}</td>";
            echo "<td class='button-container'>";
            // Edit Form
            echo "<form action='EditUser.php' method='get'>";
            echo "<input type='hidden' name='id' value='{$row['id']}'>";
            echo "<button type='submit' class='edit-button'>Edit</button>";
            echo "</form>";
            // Delete Form
            echo "<form action='' method='post'>";
            echo "<input type='hidden' name='id' value='{$row['id']}'>";
            echo "<button type='submit' class='delete-button' name='delete'>Delete</button>";
            echo "</form>";
            echo "</td>";
            echo "</tr>";
        }
        ?>
    </table>
</body>

</html>

<?php
// Handle Delete Request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    $user_id = $_POST['id'];
    // Perform delete operation
    $delete_query = "DELETE FROM user WHERE id='$user_id'";
    mysqli_query($db, $delete_query);
    // Redirect to this page to refresh the list
    //header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
// Close database connection
mysqli_close($db);
?>
