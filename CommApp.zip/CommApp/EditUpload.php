<?php
// Include your database connection file
require("fns_output.php");
require("db.php");
require("db_fns.php");

// Function to sanitize user input
function sanitize($data)
{
    return htmlspecialchars(stripslashes(trim($data)));
}

// Check if user ID is provided in the URL parameters
if (isset($_GET['uploadid']) && !empty($_GET['uploadid'])) {
    $user_id = $_GET['uploadid'];

    // Retrieve user data from the database
    $query = "SELECT * FROM uploads WHERE uploadid = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
    } else {
        echo "User documnet not found!";
        exit;
    }
} else {
    echo "socument ID not provided!";
    exit;
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $new_label = sanitize($_POST['label']);

    // Update user details in the database
    $update_query = "UPDATE uploads SET label = ? WHERE uploadid = ?";
    $stmt = $db->prepare($update_query);
    $stmt->bind_param('si', $new_label, $user_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "User details updated successfully!";
        // Redirect to manage users page or any other page
        header("Location: ManageDocument.php");
        exit;
    } else {
        echo "Failed to update user details!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Document</title>
</head>

<body>
    <h2>Edit Document</h2>
    <form method="post">
        <label for="new_Label">Label:</label><br>
        <input type="text" id="label" name="label" value="<?php echo $user['label']; ?>" required><br>
        <label for="Path">Path:</label><br>
        <input type="text" id="path" name="path" value="<?php echo $user['filename']; ?>" disabled><br>
        <input type="submit" name="submit" value="Save">
    </form>
</body>

</html>

<?php
// Close database connection
$db->close();
?>
