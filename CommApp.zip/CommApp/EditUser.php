<?php
// Include your database connection file
require("fns_output.php");
require("db.php");
require("db_fns.php");

// Function to sanitize user input
function sanitize($data)
{
    return htmlspecialchars(stripslashes(trim($data)));
}

// Check if user ID is provided in the URL parameters
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $user_id = $_GET['id'];

    // Retrieve user data from the database
    $query = "SELECT * FROM user WHERE id = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
    } else {
        echo "User not found!";
        exit;
    }
} else {
    echo "User ID not provided!";
    exit;
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $new_name = sanitize($_POST['new_name']);
    $new_email = sanitize($_POST['new_email']);

    // Update user details in the database
    $update_query = "UPDATE user SET fullname = ?, email = ? WHERE id = ?";
    $stmt = $db->prepare($update_query);
    $stmt->bind_param('ssi', $new_name, $new_email, $user_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "User details updated successfully!";
        // Redirect to manage users page or any other page
        header("Location: ManageUser.php");
        exit;
    } else {
        echo "Failed to update user details!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
</head>

<body>
    <h2>Edit User</h2>
    <form method="post">
        <label for="new_name">Name:</label><br>
        <input type="text" id="new_name" name="new_name" value="<?php echo $user['fullname']; ?>" required><br>
        <label for="new_email">Email:</label><br>
        <input type="email" id="new_email" name="new_email" value="<?php echo $user['email']; ?>" required><br>
        <input type="submit" name="submit" value="Save">
    </form>
</body>

</html>

<?php
// Close database connection
$db->close();
?>
