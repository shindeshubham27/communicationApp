<?php
require ("fns_output.php");
require ("db.php");
require ("db_fns.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all fields are filled out

    if (($_POST['email']) && ($_POST['password'])) {
        // they have just tried logging in

        $email = $_POST['email'];
        $passwd = $_POST['password'];
        
        $query = "SELECT * FROM user WHERE email=? AND password=?";
        $stmt = $db->prepare($query);
        $stmt->bind_param('ss', $email, $passwd);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            // Successful login
            session_start();
            $_SESSION['email'] = $email;
            header("Location: index.php");
            echo "<p>logged in...!<br/></p>";            
            exit;
        } else {
            // unsuccessful login
            // do_html_header("Problem:");
            echo "<p>You could not be logged in.<br/>
           enter corect details.</p>";
            do_html_url('Login.php', 'Login');
            //do_html_footer();
            exit;
        }
    } else {
        echo "<p>User name and password is required.<br/></p>";
    }
}
?>