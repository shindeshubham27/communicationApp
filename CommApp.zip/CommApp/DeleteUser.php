<?php
// Include your database connection file
require ("fns_output.php");
require ("db.php");
require ("db_fns.php");

// Handle Delete Request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    $user_id = $_POST['id'];
    // Perform delete operation
    $delete_query = "DELETE FROM user WHERE id='$user_id'";
    mysqli_query($db, $delete_query);
    // Redirect to this page to refresh the list
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
// Close database connection
mysqli_close($db);
?>