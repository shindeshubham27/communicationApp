<?php
// Include your database connection file
require ("fns_output.php");
require ("db.php");
require ("db_fns.php");
include ("Header.php");

// Function to sanitize user input
function sanitize($data)
{
    return htmlspecialchars(stripslashes(trim($data)));
}

// Query to fetch users from the database
$query = "SELECT * FROM uploads";
$result = mysqli_query($db, $query);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Document</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
        }

        .edit-button,
        .delete-button {
            padding: 6px 12px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <h2>Manage Document</h2>
    <table>
        <tr>
            <th>Label</th>
            <th>FileName</th>
            <th>Actions</th>
        </tr>
        <?php
        // Display users from database
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>{$row['label']}</td>";
            echo "<td>{$row['filename']}</td>";
            echo "<td class='button-container'>";
            // Edit Form
            echo "<form action='EditUpload.php' method='get'>";
            echo "<input type='hidden' name='uploadid' value='{$row['uploadid']}'>";
            echo "<button type='submit' class='edit-button'>Edit</button>";
            echo "</form>";
            // Delete Form
            echo "<form action='' method='post'>";
            echo "<input type='hidden' name='uploadid' value='{$row['uploadid']}'>";
            echo "<button type='submit' class='delete-button' name='delete'>Delete</button>";
            echo "</form>";
            echo "</td>";
            echo "</tr>";
        }
        ?>
    </table>
    <div style="padding: 6px 12px; margin-top:20px;">
        <form action="upload.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="MAX_FILE_SIZE" value="10000000">
            <label for="" class='delete-button'>Upload a file</label>
            <input type="file" name="userfile">
            <input type="submit" class='delete-button' value="Upload File">
        </form>
    </div>
</body>


</html>

<?php
// Handle Delete Request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    $user_id = $_POST['uploadid'];
    // Perform delete operation
    $delete_query = "DELETE FROM uploads WHERE uploadid='$user_id'";
    mysqli_query($db, $delete_query);
    // Redirect to this page to refresh the list
    //header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
// Close database connection
mysqli_close($db);
?>