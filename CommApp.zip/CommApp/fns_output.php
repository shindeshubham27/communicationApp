<?php

function do_html_URL($url, $name) {
  // output URL as link and br    do_html_url("admin.php", "Back to administration menu");
?>
  <a href="<?php echo ($url); ?>"><?php echo ($name); ?></a><br />
<?php
}


?>
