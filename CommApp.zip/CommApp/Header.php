

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header with Buttons</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }
        .button-container {
            display: flex;
            justify-content: space-around;
            padding: 10px;
        }
        .button-container button {
            padding: 10px 20px;
            background-color: #13ddf3;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <header>
        <div class="button-container">
            <button><a href="Groupchat.php">Group Chat</a></button>
            <button><a href="ManageUser.php">Manage User</a></button>
            <button><a href="ManageDocument.php">Manage Document</a></button>
            <button><a href="Logout.php">Logout</a></button>
        </div>
    </header>
    <div>
</body>
</html>
