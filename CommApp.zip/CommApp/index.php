<?php
// Disable warnings
ini_set('display_errors', '0');
include("Header.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    </head>
<body>
    <div>
        <div>
            <h2></br>
                <?php
                session_start();
                $email = $_SESSION["email"];
                if($email)
                {
                    echo "<div>Logged In user - " . $email . "";
                }
                else
                {
                    header("Location: Welcome.php"  );
                }
                ?>
            </h2>;
        </div>
</body>

</html>