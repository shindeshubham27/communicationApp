<?php

function db_result_to_array($result) {
   $res_array = array();

   for ($count=0; $row = $result->fetch_assoc(); $count++) {
     $res_array[$count] = $row;
   }

   return $res_array;
}


function filled_out($form_vars) {
   // test that each variable has a value
   foreach ($form_vars as $key => $value) {
      if ((!isset($key)) || ($value == '')) {
         return false;
      }
   }
   return true;
 }



 function display_error($error_msg)
{
    echo "<div><p>$error_msg</p></div>";
}
?>