<?php
require("uploadFunction.php");
require ("fns_output.php");
require ("db.php");
require ("db_fns.php");
include ("Header.php");

if ($_FILES['userfile']['error'] > 0) {
    switch ($_FILES['userfile']['error']) {
        case 1:
            echo "File exceeded upload_max_file_size";
            break;

        case 2:
            echo "File exceeded upload max_file_size";
            break;

        case 3:
            echo "File only partially uploaded";
            break;

        case 4:
            echo "no file uploaded";
            break;
    }
}

// MIME Type
if ($_FILES['userfile']['type'] != 'image/png') {
    echo "Problem: File is not a PNG file";
    exit;
}

$document_path = $_SERVER['DOCUMENT_ROOT']; // /Applications/MAMP/htdocs
$uploaded_file_path = $document_path . "/uploads/" . $_FILES['userfile']['name'];

$val = 0;
$query = "INSERT INTO uploads VALUES (?, ?, ?)";
$stmt = $db->prepare($query);
$stmt->bind_param('iss', $val, $_FILES['userfile'], $uploaded_file_path);
$stmt->execute();

uploadFile($uploaded_file_path);
displayUploadedImage($_FILES['userfile']['name']);
