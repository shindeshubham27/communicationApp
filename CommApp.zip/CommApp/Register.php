<?php

require ("fns_output.php");
require ("db.php");
require ("db_fns.php");


// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullName = $_POST["fullName"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $confirmPassword = $_POST["confirmPassword"];
    // Check if all fields are filled out
    if ($fullName && $email && $password && $confirmPassword) {
      
        // Check if passwords match
        if ($password !== $confirmPassword) {
            display_error("Passwords do not match.");
            do_html_url("Register.php", "back to Register page");
        } else {
            // Insert user if all checks pass
            $val = 0;
            $query = "INSERT INTO user VALUES (?, ?, ?, ?)";
            $stmt = $db->prepare($query);
            $stmt->bind_param('isss', $val, $fullName, $email, $password);
            $stmt->execute();

            // Check if the statement execution was successful
            if ($stmt->affected_rows > 0) {
                echo "<div><h2>Registration Successful.!</br>Welcome " . $fullName . "</h2>";
                echo "<p>Thank you for your registration!</p></div>";
                do_html_url("index.php", "home page");
                exit; // Stop further execution
            } else {
                display_error("Registration Unsuccessful.");
                do_html_url("Register.php", "back to Register page");
                exit;
            }

        }
    } else {
        display_error("Please fill out all details.");
        do_html_url("Register.php", "back to Register page");
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>

<body>
    <div>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <h1>Register</h1>
            <table>
                <tr>
                    <td><label for="fullName">Full Name:</label></td>
                    <td><input type="text" id="fullName" name="fullName"></td>
                </tr>
                <tr>
                    <td><label for="email">Email:</label></td>
                    <td><input type="email" id="email" name="email"></td>
                </tr>
                <tr>
                    <td><label for="password">Password:</label></td>
                    <td><input type="password" id="password" name="password"></td>
                </tr>
                <tr>
                    <td><label for="confirmPassword">Confirm Password:</label></td>
                    <td><input type="password" id="confirmPassword" name="confirmPassword"></td>
                </tr>
            </table>
            <br>
            <input type="submit" value="Register">
        </form>
    </div>
</body>

</html>