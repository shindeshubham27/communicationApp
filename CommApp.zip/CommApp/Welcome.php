<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to User Module</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 50px;
        }
        h1 {
            color: #333;
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #13ddf3;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 10px;
        }
    </style>
</head>
<body>
    <h1>Welcome to User Module</h1>
    <label for="existingUser">Existing User</label><br>
    <a href="login.php" class="button">Login</a><br>
    <label for="newUser">New User</label><br>
    <a href="Register.php" class="button">Register</a><br>
</body>
</html>
