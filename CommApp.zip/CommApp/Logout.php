<?php
require("fns_output.php");
require("db.php");
require("db_fns.php");

session_start();
$old_user = $_SESSION['email'];  // store  to test if they *were* logged in
unset($_SESSION['email']);
session_destroy();

if (!empty($old_user)) {
  echo "<p>Logged out.</p>";
  do_html_url("Login.php", "Login");
} else {
  // if they weren't logged in but came to this page somehow
  echo "<p>You were not logged in, and so have not been logged out.</p>";
  do_html_url("Login.php", "Login");
}

?>
